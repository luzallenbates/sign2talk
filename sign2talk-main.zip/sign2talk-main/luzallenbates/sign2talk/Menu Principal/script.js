let button = document.getElementById("quadrado");

button.addEventListener("click", function(){
    window.location.href="file:///C:/Users/DESKTOP%2025%20LAB%20INFO.DESKTOP-RTHFNLT/Desktop/luzallenbates/sign2talk/PaginaTradução/VideoTexto.html";
});