let entrar = document.getElementById("entrar");

entrar.addEventListener("click", function() {
    window.location.href = "file:///C:/Users/DESKTOP%2025%20LAB%20INFO.DESKTOP-RTHFNLT/Desktop/luzallenbates/sign2talk/Menu Principal/index.html";
});