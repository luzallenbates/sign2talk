Index created as a startpage of the app's "skeleton"
